﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Data
{
    public static float coin = 300;
    public static bool isGameOver = false;
    public static bool isComplate = false;
}